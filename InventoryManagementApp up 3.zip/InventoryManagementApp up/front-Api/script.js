// script.js

document.addEventListener('DOMContentLoaded', function () {
    // Fetch and display inventory items on page load
    fetchInventoryItems();

    // Add event listener to the form for adding/editing items
    document.getElementById('inventory-form').addEventListener('submit', function (event) {
        event.preventDefault();
        saveInventoryItem();
    });
});

async function fetchInventoryItems() {
    try {
        const response = await fetch('http://localhost:8484/api/v1/inventory');
        if (!response.ok) {
            throw new Error('Failed to fetch inventory items');
        }

        const items = await response.json();

        // Clear existing table rows
        const tableBody = document.querySelector('#inventory-table tbody');
        tableBody.innerHTML = '';

        // Populate table with inventory items
        items.forEach(item => {
            const row = tableBody.insertRow();
            row.setAttribute('data-id', item.product_id);  // Added this line
            row.innerHTML = `<td>${item.product_id}</td>
                             <td>${item.product_name}</td>
                             <td>${item.description}</td>
                             <td>${item.price}</td>
                             <td>${item.category}</td>
                             <td>${item.stock_quantity}</td>
                             <td>
                                 <button onclick="editItem(${item.product_id})">Edit</button>
                                 <button onclick="deleteItem(${item.product_id})">Delete</button>
                             </td>`;
        });
    } catch (error) {
        console.error(error.message);
    }
}

async function saveInventoryItem() {
    try {
        const itemName = document.getElementById('itemName').value;
        const itemDescription = document.getElementById('itemDescription').value;
        const itemPrice = document.getElementById('itemPrice').value;
        const itemCategory = document.getElementById('itemCategory').value;
        const itemStockQuantity = document.getElementById('itemStockQuantity').value;

        const item = {
            product_name: itemName,
            description: itemDescription,
            price: itemPrice,
            category: itemCategory,
            stock_quantity: itemStockQuantity,
        };

        // Check if there is an existing item ID in the form
        const itemId = document.getElementById('item-id').value;
        const url = itemId ? `http://localhost:8484/api/v1/inventory/${itemId}` : 'http://localhost:8484/api/v1/inventory';

        const response = await fetch(url, {
            method: itemId ? 'PUT' : 'POST',  // Use PUT for updates, POST for new items
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(item),
        });

        if (!response.ok) {
            throw new Error(`Failed to ${itemId ? 'update' : 'save'} inventory item`);
        }

        // Clear form fields and fetch updated items
        document.getElementById('itemName').value = '';
        document.getElementById('itemDescription').value = '';
        document.getElementById('itemPrice').value = '';
        document.getElementById('itemCategory').value = '';
        document.getElementById('itemStockQuantity').value = '';
        document.getElementById('item-id').value = '';  // Clear the item ID field
        fetchInventoryItems();
    } catch (error) {
        console.error(error.message);
    }
}


async function editItem(itemId) {
    try {
        // Fetch the details of the item with the given ID
        const response = await fetch(`http://localhost:8484/api/v1/inventory/${itemId}`);
        if (!response.ok) {
            throw new Error('Failed to fetch item details for editing');
        }

        const itemDetails = await response.json();

        // Populate form fields with existing values
        document.getElementById('itemName').value = itemDetails.product_name;
        document.getElementById('itemDescription').value = itemDetails.description;
        document.getElementById('itemPrice').value = itemDetails.price;
        document.getElementById('itemCategory').value = itemDetails.category;
        document.getElementById('itemStockQuantity').value = itemDetails.stock_quantity;
        // Set the item ID in the hidden input field
        document.getElementById('item-id').value = itemDetails.product_id;
    } catch (error) {
        console.error(error.message);
    }
}

async function deleteItem(itemId) {
    console.log(`Delete item with ID: ${itemId}`);

    try {
        const response = await fetch(`http://localhost:8484/api/v1/inventory/${itemId}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            throw new Error('Failed to delete inventory item');
        }

        // Remove the corresponding row from the table
        const tableBody = document.querySelector('#inventory-table tbody');
        const rowToRemove = tableBody.querySelector(`[data-id="${itemId}"]`);

        if (rowToRemove) {
            rowToRemove.remove();

            // Fetch and display updated inventory items after deletion
            fetchInventoryItems();
        } else {
            console.error(`Row with ID ${itemId} not found.`);
        }
    } catch (error) {
        console.error(error.message);
    }
}

//user part 

// script1.js

document.addEventListener('DOMContentLoaded', function () {
    // Fetch and display users on page load
    fetchUsers();

    // Add event listener to the user form
    document.getElementById('user-form').addEventListener('submit', function (event) {
        event.preventDefault();
        saveUser();
    });
});

async function fetchUsers() {
    try {
        const response = await fetch('http://localhost:8283/api/v1/users');
        if (!response.ok) {
            throw new Error('Failed to fetch user data');
        }

        const users = await response.json();

        // Clear existing table rows
        const userTableBody = document.querySelector('#user-table tbody');
        userTableBody.innerHTML = '';

        // Populate table with user data
        users.forEach(user => {
            const row = userTableBody.insertRow();
            row.setAttribute('data-id', user.user_id);
            row.innerHTML = `<td>${user.user_id}</td>
                             <td>${user.username}</td>
                             <td>${user.password}</td>
                             <td>${user.email}</td>
                             <td>${user.first_name}</td>
                             <td>${user.last_name}</td>
                             <td>${user.phone_number}</td>
                             <td>${user.registration_date}</td>
                             <td>
                                 <button onclick="editUser(${user.user_id})">Edit</button>
                                 <button onclick="deleteUser(${user.user_id})">Delete</button>
                             </td>`;
        });
    } catch (error) {
        console.error(error.message);
    }
}

async function saveUser() {
    try {
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const phoneNumber = document.getElementById('phoneNumber').value;
        const registrationDate = document.getElementById('registrationDate').value;


        const user = {
            username: username,
            email: email,
            password: password,
            first_name: firstName,
            last_name: lastName,
            phone_number: phoneNumber,
            registration_date: registrationDate,

        };

        // Check if there is an existing user ID in the form
        const userId = document.getElementById('user-id').value;
        const url = userId ? `http://localhost:8283/api/v1/users/${userId}` : 'http://localhost:8283/api/v1/users';

        const response = await fetch(url, {
            method: userId ? 'PUT' : 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(user),
        });

        if (!response.ok) {
            throw new Error(`Failed to ${userId ? 'update' : 'save'} user`);
        }

        // Clear form fields and fetch updated users
        document.getElementById('username').value = '';
        document.getElementById('email').value = '';
        document.getElementById('password').value = '';
        document.getElementById('firstName').value = '';
        document.getElementById('lastName').value = '';
        document.getElementById('phoneNumber').value = '';
        document.getElementById('registrationDate').value = ''; // Clear registration date field
        document.getElementById('user-id').value = '';
        fetchUsers();
    } catch (error) {
        console.error(error.message);
    }
}

async function editUser(userId) {
    try {
        const response = await fetch(`http://localhost:8283/api/v1/users/${userId}`);
        if (!response.ok) {
            throw new Error('Failed to fetch user details for editing');
        }

        const userDetails = await response.json();

        // Populate form fields with existing values
        document.getElementById('username').value = userDetails.username;
        document.getElementById('email').value = userDetails.email;
        document.getElementById('password').value = userDetails.password;
        document.getElementById('firstName').value = userDetails.first_name;
        document.getElementById('lastName').value = userDetails.last_name;
        document.getElementById('phoneNumber').value = userDetails.phone_number;
        document.getElementById('registrationDate').value = userDetails.registration_date;
        document.getElementById('user-id').value = userDetails.user_id;
    } catch (error) {
        console.error(error.message);
    }
}

async function deleteUser(userId) {
    console.log(`Delete user with ID: ${userId}`);

    try {
        const response = await fetch(`http://localhost:8283/api/v1/users/${userId}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            throw new Error('Failed to delete user');
        }

        // Remove the corresponding row from the table
        const userTableBody = document.querySelector('#user-table tbody');
        const rowToRemove = userTableBody.querySelector(`[data-id="${userId}"]`);

        if (rowToRemove) {
            rowToRemove.remove();
            fetchUsers();
        } else {
            console.error(`Row with ID ${userId} not found.`);
        }
    } catch (error) {
        console.error(error.message);
    }
}
