document.addEventListener('DOMContentLoaded', function () {
    // Fetch and display inventory items on page load
    fetchInventoryItems();

    // Add event listener to the form for adding/editing items
    document.getElementById('inventory-form').addEventListener('submit', function (event) {
        event.preventDefault();
        saveInventoryItem();
    });
});

async function fetchInventoryItems() {
    const response = await fetch('https://localhost:8484/api/v1/inventory');
    const items = await response.json();

    // Clear existing table rows
    const tableBody = document.querySelector('#inventory-table tbody');
    tableBody.innerHTML = '';

    // Populate table with inventory items
    items.forEach(item => {
        const row = tableBody.insertRow();
        row.innerHTML = `<td>${item.product_id}</td>
                         <td>${item.product_name}</td>
                         <td>${item.description}</td>
                         <td>${item.price}</td>
                         <td>${item.category}</td>
                         <td>${item.stock_quantity}</td>
                         
                         <td>
                             <button onclick="editItem(${item.product_id})">Edit</button>
                             <button onclick="deleteItem(${item.product_id})">Delete</button>
                         </td>`;
    });
}

async function saveInventoryItem() {
    const itemName = document.getElementById('itemName').value;
    const itemQuantity = document.getElementById('itemQuantity').value;

    // You can add more fields based on your backend model

    const item = {
        product_name: itemName,
        quantity: itemQuantity,
    };

    const response = await fetch('https://your-backend-url/api/v1/inventory', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(item),
    });

    if (response.ok) {
        // Clear form fields and fetch updated items
        document.getElementById('itemName').value = '';
        document.getElementById('itemQuantity').value = '';
        fetchInventoryItems();
    } else {
        console.error('Failed to save inventory item');
    }
}

function editItem(itemId) {
    // Implement the logic to load the item details for editing
    console.log('Edit item with ID:', itemId);
}

function deleteItem(itemId) {
    // Implement the logic to delete the item
    console.log('Delete item with ID:', itemId);
}
