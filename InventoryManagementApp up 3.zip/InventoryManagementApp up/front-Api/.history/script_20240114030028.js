document.addEventListener('DOMContentLoaded', function () {
    // Fetch and display inventory items on page load
    fetchInventoryItems();

    // Add event listener to the form for adding/editing items
    document.getElementById('inventory-form').addEventListener('submit', function (event) {
        event.preventDefault();
        saveInventoryItem();
    });
});

async function fetchInventoryItems() {
    try {
        const response = await fetch('https://localhost:8484/api/v1/inventory');
        if (!response.ok) {
            throw new Error('Failed to fetch inventory items');
        }

        const items = await response.json();

        // Clear existing table rows
        const tableBody = document.querySelector('#inventory-table tbody');
        tableBody.innerHTML = '';

        // Populate table with inventory items
        items.forEach(item => {
            const row = tableBody.insertRow();
            row.innerHTML = `<td>${item.product_id}</td>
                             <td>${item.product_name}</td>
                             <td>${item.description}</td>
                             <td>${item.price}</td>
                             <td>${item.category}</td>
                             <td>${item.stock_quantity}</td>
                             <td>${item.photo_id}</td>
                             <td>${item.photo_data}</td>
                             <td>
                                 <button onclick="editItem(${item.product_id})">Edit</button>
                                 <button onclick="deleteItem(${item.product_id})">Delete</button>
                             </td>`;
        });
    } catch (error) {
        console.error(error.message);
    }
}

async function saveInventoryItem() {
    try {
        const itemName = document.getElementById('itemName').value;
        const itemDescription = document.getElementById('itemDescription').value;
        const itemPrice = document.getElementById('itemPrice').value;
        const itemCategory = document.getElementById('itemCategory').value;
        const itemStockQuantity = document.getElementById('itemStockQuantity').value;

        // You can add more fields based on your backend model

        const item = {
            product_name: itemName,
            description: itemDescription,
            price: itemPrice,
            category: itemCategory,
            stock_quantity: itemStockQuantity,
        };

        const response = await fetch('https://localhost:8484/api/v1/inventory', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(item),
        });

        if (!response.ok) {
            throw new Error('Failed to save inventory item');
        }

        // Clear form fields and fetch updated items
        document.getElementById('itemName').value = '';
        document.getElementById('itemDescription').value = '';
        document.getElementById('itemPrice').value = '';
        document.getElementById('itemCategory').value = '';
        document.getElementById('itemStockQuantity').value = '';
        fetchInventoryItems();
    } catch (error) {
        console.error(error.message);
    }
}

function editItem(itemId) {
    // Implement the logic to load the item details for editing
    console.log('Edit item with ID:', itemId);
}

async function deleteItem(itemId) {
    try {
        const response = await fetch(`https://localhost:8484/api/v1/inventory/${itemId}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            throw new Error('Failed to delete inventory item');
        }

        // Fetch and display updated inventory items after deletion
        fetchInventoryItems();
    } catch (error) {
        console.error(error.message);
    }
}
