 // InventoryManagement.Api/Models/InventoryItem.cs
namespace InventoryManagement.Api.Models
{
    public class ManagementUser
    {
        public int? user_id { get; set; }
        public string? username { get; set; }
        public string? email { get; set; }
        public string? password{ get; set; }
        public string? first_name{ get; set; }
        public string? last_name{ get; set; }
      public string? phone_number{ get; set; }

        public string? registration_date { get; set; }
 



        // Default constructor with properties initialization
        public ManagementUser()
        {
            user_id = null;
            username = null;
            email = null;
            password = null;
            first_name = null;
            last_name = null;
            phone_number=null;
            registration_date = null;
        }
    }
}