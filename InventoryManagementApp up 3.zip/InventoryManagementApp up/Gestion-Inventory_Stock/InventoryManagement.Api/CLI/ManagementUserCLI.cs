// ManagementUserCLI.cs
using System;
using System.Threading.Tasks;
using InventoryManagement.Api.Repositories;
using InventoryManagement.Api.Models;

namespace InventoryManagement.Api
{
    public class ManagementUserCLI
    {
        private readonly ManagementUserRepository _userRepository;

        public ManagementUserCLI()
        {
            _userRepository = new ManagementUserRepository();
        }

        public async Task StartAsync()
        {
            Console.WriteLine("Management User CLI");
            Console.WriteLine("Commands:");
            Console.WriteLine("1. View Users: view");
            Console.WriteLine("2. Add User: add");
            Console.WriteLine("3. Update User: update");
            Console.WriteLine("4. Delete User: delete");
            Console.WriteLine("5. Exit: exit");

            while (true)
            {
                Console.Write("Enter a command: ");
                var command = Console.ReadLine()?.ToLower();

                switch (command)
                {
                    case "view":
                        await ViewUsersAsync();
                        break;
                    case "add":
                        await AddUserAsync();
                        break;
                    case "update":
                        await UpdateUserAsync();
                        break;
                    case "delete":
                        await DeleteUserAsync();
                        break;
                    case "exit":
                        return;
                    default:
                        Console.WriteLine("Invalid command. Try again.");
                        break;
                }
            }
        }

        private async Task ViewUsersAsync()
        {
            var users = await _userRepository.GetAllUsersAsync();
            if (users != null)
            {
                Console.WriteLine("Viewing Users:");
                foreach (var user in users)
                {
                    Console.WriteLine($"ID: {user.user_id}, Username: {user.username}, Email: {user.email}, Registration Date: {user.registration_date}");
                }
            }
            else
            {
                Console.WriteLine("Error fetching users. Please try again.");
            }
        }

        private async Task AddUserAsync()
        {
            Console.WriteLine("Adding User:");

            var newUser = new ManagementUser();

            Console.Write("Enter username: ");
            newUser.username = Console.ReadLine();

            Console.Write("Enter email: ");
            newUser.email = Console.ReadLine();

            Console.Write("Enter password: ");
            newUser.password = Console.ReadLine();

            Console.Write("Enter first name: ");
            newUser.first_name = Console.ReadLine();

            Console.Write("Enter last name: ");
            newUser.last_name = Console.ReadLine();

            // Assuming registration_date is automatically set in the repository
newUser.registration_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            await _userRepository.AddUserAsync(newUser);
            Console.WriteLine("User added successfully.");
        }

        private async Task UpdateUserAsync()
        {
            Console.WriteLine("Updating User:");

            Console.Write("Enter user ID to update: ");
            if (int.TryParse(Console.ReadLine(), out var userId))
            {
                var existingUser = await _userRepository.GetUserByIdAsync(userId);
                if (existingUser != null)
                {
                    Console.Write("Enter new username: ");
                    existingUser.username = Console.ReadLine();

                    Console.Write("Enter new email: ");
                    existingUser.email = Console.ReadLine();

                    Console.Write("Enter new password: ");
                    existingUser.password = Console.ReadLine();

                    Console.Write("Enter new first name: ");
                    existingUser.first_name = Console.ReadLine();

                    Console.Write("Enter new last name: ");
                    existingUser.last_name = Console.ReadLine();

                    // Assuming registration_date is not updated

                    await _userRepository.UpdateUserAsync(existingUser);
                    Console.WriteLine("User updated successfully.");
                }
                else
                {
                    Console.WriteLine($"User with ID {userId} not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid user ID.");
            }
        }

        private async Task DeleteUserAsync()
        {
            Console.WriteLine("Deleting User:");

            Console.Write("Enter user ID to delete: ");
            if (int.TryParse(Console.ReadLine(), out var userId))
            {
                var existingUser = await _userRepository.GetUserByIdAsync(userId);
                if (existingUser != null)
                {
                    await _userRepository.DeleteUserAsync(userId);
                    Console.WriteLine("User deleted successfully.");
                }
                else
                {
                    Console.WriteLine($"User with ID {userId} not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid user ID.");
            }
        }
    }
}
