// InventoryCLI.cs
using System;
using System.Threading.Tasks;
using InventoryManagement.Api.Repositories;
using InventoryManagement.Api.Models;

namespace InventoryManagement.Api
{
    public class InventoryCLI
    {
        private readonly InventoryRepository _repository;

        public InventoryCLI()
        {
            _repository = new InventoryRepository();
        }
//affichage du menu
        public async Task StartAsync()
        {
            Console.WriteLine("Inventory Management CLI");
            Console.WriteLine("Commands:");
            Console.WriteLine("1. View Inventory: view");
            Console.WriteLine("2. Add Item: add");
            Console.WriteLine("3. Update Item: update");
            Console.WriteLine("4. Delete Item: delete");
            Console.WriteLine("5. Exit: exit");
//boucle traitement des commandes
            while (true)
            {
                Console.Write("Enter a command: ");
                var command = Console.ReadLine()?.ToLower();

                switch (command)
                {
                    case "view":
                        await ViewInventoryAsync();
                        break;
                    case "add":
                        await AddItemAsync();
                        break;
                    case "update":
                        await UpdateItemAsync();
                        break;
                    case "delete":
                        await DeleteItemAsync();
                        break;
                    case "exit":
                        return;
                    default:
                        Console.WriteLine("Invalid command. Try again.");
                        break;
                }
            }
        }

        // Voir les inventory
        private async Task ViewInventoryAsync()
        {
            var items = await _repository.GetItemsAsync();
            if (items != null)
            {
                Console.WriteLine("Viewing Inventory:");
                foreach (var item in items)
                {
Console.WriteLine($"ID: {item.product_id}, Name: {item.product_name}, Price: {item.price}, Category: {item.category}, Stock: {item.stock_quantity}, Photo ID: {item.photo_id}, Photo Data: {item.photo_data}");
                }
            }
            else
            {
                Console.WriteLine("Error fetching inventory. Please try again.");
            }
        }

        // Ajout nouveau inventory
        private async Task AddItemAsync()
        {
            Console.WriteLine("Adding Item:");

            var newItem = new InventoryItem();

            // Collect information for the new item
            Console.Write("Enter product name: ");
            newItem.product_name = Console.ReadLine();

            Console.Write("Enter description: ");
            newItem.description = Console.ReadLine();

            Console.Write("Enter price: ");
            if (double.TryParse(Console.ReadLine(), out double price))
            {
                newItem.price = price;
            }
            else
            {
                Console.WriteLine("Invalid price format. Setting price to null.");
                newItem.price = null;
            }

            Console.Write("Enter category: ");
            newItem.category = Console.ReadLine();

            Console.Write("Enter stock quantity: ");
            if (int.TryParse(Console.ReadLine(), out int stockQuantity))
            {
                newItem.stock_quantity = stockQuantity;
            }
            else
            {
                Console.WriteLine("Invalid stock quantity format. Setting stock quantity to null.");
                newItem.stock_quantity = null;
            }

            await _repository.AddItemAsync(newItem);
            Console.WriteLine("Item added successfully.");
        }

        // Update an existing item in the inventory
       private async Task UpdateItemAsync()
{
    Console.WriteLine("Updating Item:");

    Console.Write("Enter product ID to update: ");
    if (int.TryParse(Console.ReadLine(), out var productId))
    {
        var existingItem = await _repository.GetItemByIdAsync(productId);
        if (existingItem != null)
        {
            // Collect updated information for the existing item
            Console.Write("Enter new product name: ");
            existingItem.product_name = Console.ReadLine();

            Console.Write("Enter new description: ");
            existingItem.description = Console.ReadLine();

            Console.Write("Enter new price: ");
            if (double.TryParse(Console.ReadLine(), out double price))
            {
                existingItem.price = price;
            }
            else
            {
                Console.WriteLine("Invalid price format. Keeping the existing price.");
            }

            Console.Write("Enter new category: ");
            existingItem.category = Console.ReadLine();

            Console.Write("Enter new stock quantity: ");
            if (int.TryParse(Console.ReadLine(), out int stockQuantity))
            {
                existingItem.stock_quantity = stockQuantity;
            }
            else
            {
                Console.WriteLine("Invalid stock quantity format. Keeping the existing stock quantity.");
            }

            await _repository.UpdateItemAsync(existingItem);
            Console.WriteLine("Item updated successfully.");
        }
        else
        {
            Console.WriteLine($"Item with ID {productId} not found.");
        }
    }
    else
    {
        Console.WriteLine("Invalid input. Please enter a valid product ID.");
    }
}

        // Delete an item from the inventory
        private async Task DeleteItemAsync()
        {
            Console.WriteLine("Deleting Item:");

            Console.Write("Enter product ID to delete: ");
            if (int.TryParse(Console.ReadLine(), out var productId))
            {
                var existingItem = await _repository.GetItemByIdAsync(productId);
                if (existingItem != null)
                {
                    await _repository.DeleteItemAsync(productId);
                    Console.WriteLine("Item deleted successfully.");
                }
                else
                {
                    Console.WriteLine($"Item with ID {productId} not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid product ID.");
            }
        }
    }
}
