using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using InventoryManagement.Api.Models;

namespace InventoryManagement.Api.Repositories
{
    public class InventoryRepository
    {
        // Connection string for the MySQL database
        private string connectionString = "Server=127.0.0.1;Database=e-commerce;User Id=root;Password=yvan2021;";

        // Asynchronously tests the connection to the database
        public async Task<bool> TestDatabaseConnectionAsync()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Open the database connection
                    await connection.OpenAsync();
                    Console.WriteLine("Connection to the database is successful.");
                    return true;
                }
            }
            catch (MySqlException ex)
            {
                // Handle MySQL-specific exceptions related to database connection
                Console.WriteLine($"Database connection error: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                // Handle general exceptions related to database connection
                Console.WriteLine($"Error connecting to the database: {ex.Message}");
                return false;
            }
        }

        // Asynchronously retrieves a list of all inventory items from the database
        public async Task<List<InventoryItem>> GetItemsAsync()
        {
            List<InventoryItem> items = new List<InventoryItem>();

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Open the database connection
                    await connection.OpenAsync();

                    // Execute a SELECT query to fetch all items from the 'product' table
            using (MySqlCommand command = new MySqlCommand("SELECT p.*, ph.photo_id, ph.photo_data FROM product p LEFT JOIN photo ph ON p.product_id = ph.product_id", connection))
                    using (MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync())
                    {
                        // Read each row and map it to an InventoryItem
                        while (await reader.ReadAsync())
                        {
                            InventoryItem item = MapInventoryItem(reader);
                            items.Add(item);
                        }
                    }
                }
            }
            catch (MySqlException ex)
            {
                // Handle exceptions related to fetching items from the database
                HandleDatabaseException(ex, "Error fetching items from the database.");
            }

            return items;
        }

        // Asynchronously retrieves an inventory item by its ID from the database
     public async Task<InventoryItem?> GetItemByIdAsync(int id)
{
    try
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            // Open the database connection
            await connection.OpenAsync();

            // Execute a SELECT query to fetch an item by its ID from the 'product' table
            using (MySqlCommand command = new MySqlCommand("SELECT product.*, photo.photo_id, photo.photo_data " +
                                                           "FROM product " +
                                                           "LEFT JOIN photo ON product.product_id = photo.product_id " +
                                                           "WHERE product.product_id = @product_id", connection))
            {
                command.Parameters.AddWithValue("@product_id", id);

                using (MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync())
                {
                    // If a matching item is found, map it to an InventoryItem
                    if (await reader.ReadAsync())
                    {
                        return MapInventoryItem(reader);
                    }
                }
            }
        }
    }
    catch (MySqlException ex)
    {
        // Handle exceptions related to fetching an item by ID from the database
        HandleDatabaseException(ex, "Error fetching item by ID from the database.");
    }

    return null; // Item not found or an error occurred
}


        // Asynchronously adds a new inventory item to the database
        public async Task AddItemAsync(InventoryItem item)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Open the database connection
                    await connection.OpenAsync();

                    // Execute an INSERT query to add a new item to the 'product' table
                    using (MySqlCommand command = new MySqlCommand("INSERT INTO product (product_name, description, price, category, stock_quantity) VALUES (@product_name, @description, @price, @category, @stock_quantity)", connection))
                    {
                        // Set parameters for the new item
                        AddInventoryItemParameters(command, item);

                        // Execute the query
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (MySqlException ex)
            {
                // Handle exceptions related to adding an item to the database
                HandleDatabaseException(ex, "Error adding item to the database.");
            }
        }

        // Asynchronously updates an existing inventory item in the database
        public async Task UpdateItemAsync(InventoryItem item)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Open the database connection
                    await connection.OpenAsync();

                    // Execute an UPDATE query to update an item in the 'product' table
                    using (MySqlCommand command = new MySqlCommand("UPDATE product SET product_name = @product_name, description = @description, price = @price, category = @category, stock_quantity = @stock_quantity WHERE product_id = @product_id", connection))
                    {
                        // Set parameters for the updated item
                        command.Parameters.AddWithValue("@product_id", item.product_id);
                        AddInventoryItemParameters(command, item);

                        // Execute the query
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (MySqlException ex)
            {
                // Handle exceptions related to updating an item in the database
                HandleDatabaseException(ex, "Error updating item in the database.");
            }
        }

        // Asynchronously deletes an existing inventory item from the database
     public async Task DeleteItemAsync(int id)
{
    try
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            await connection.OpenAsync();

            using (MySqlTransaction transaction = await connection.BeginTransactionAsync())
            {
                try
                {
                    // Delete associated records in the 'cart' table
                    using (MySqlCommand deleteCartCommand = new MySqlCommand("DELETE FROM cart WHERE product_id = @product_id", connection, transaction))
                    {
                        deleteCartCommand.Parameters.AddWithValue("@product_id", id);
                        await deleteCartCommand.ExecuteNonQueryAsync();
                    }

                    // Delete associated records in the 'command' table
                    using (MySqlCommand deleteCommandRecordsCommand = new MySqlCommand("DELETE FROM command WHERE product_id = @product_id", connection, transaction))
                    {
                        deleteCommandRecordsCommand.Parameters.AddWithValue("@product_id", id);
                        await deleteCommandRecordsCommand.ExecuteNonQueryAsync();
                    }

                    // Delete associated records in the 'rate' table
                    using (MySqlCommand deleteRateRecordsCommand = new MySqlCommand("DELETE FROM rate WHERE product_id = @product_id", connection, transaction))
                    {
                        deleteRateRecordsCommand.Parameters.AddWithValue("@product_id", id);
                        await deleteRateRecordsCommand.ExecuteNonQueryAsync();
                    }

                    // Delete associated records in the 'promotion' table
                    using (MySqlCommand deleteRateRecordsCommand = new MySqlCommand("DELETE FROM promotion WHERE product_id = @product_id", connection, transaction))
                    {
                        deleteRateRecordsCommand.Parameters.AddWithValue("@product_id", id);
                        await deleteRateRecordsCommand.ExecuteNonQueryAsync();
                    }

                    // Delete associated records in the 'inventory' table
                    using (MySqlCommand deleteRateRecordsCommand = new MySqlCommand("DELETE FROM inventory WHERE product_id = @product_id", connection, transaction))
                    {
                        deleteRateRecordsCommand.Parameters.AddWithValue("@product_id", id);
                        await deleteRateRecordsCommand.ExecuteNonQueryAsync();
                    }
                    // Delete associated records in the 'photo' table
                    using (MySqlCommand deletePhotoRecordsCommand = new MySqlCommand("DELETE FROM photo WHERE product_id = @product_id", connection, transaction))
                    {
                        deletePhotoRecordsCommand.Parameters.AddWithValue("@product_id", id);
                        await deletePhotoRecordsCommand.ExecuteNonQueryAsync();
                    }

                    // Delete associated records in the 'review' table
                    using (MySqlCommand deleteReviewRecordsCommand = new MySqlCommand("DELETE FROM review WHERE product_id = @product_id", connection, transaction))
                    {
                        deleteReviewRecordsCommand.Parameters.AddWithValue("@product_id", id);
                        await deleteReviewRecordsCommand.ExecuteNonQueryAsync();
                    }

                    // Delete associated records in the 'wishlist' table
                    using (MySqlCommand deleteWishlistRecordsCommand = new MySqlCommand("DELETE FROM wishlist WHERE product_id = @product_id", connection, transaction))
                    {
                        deleteWishlistRecordsCommand.Parameters.AddWithValue("@product_id", id);
                        await deleteWishlistRecordsCommand.ExecuteNonQueryAsync();
                    }

                    // Now, delete the item from the 'product' table
                    using (MySqlCommand deleteProductCommand = new MySqlCommand("DELETE FROM product WHERE product_id = @product_id", connection, transaction))
                    {
                        deleteProductCommand.Parameters.AddWithValue("@product_id", id);
                        await deleteProductCommand.ExecuteNonQueryAsync();
                    }

                    // Commit the transaction if everything is successful
                    transaction.Commit();
                }
                catch (Exception)
                {
                    // Rollback the transaction in case of any error
                    transaction.Rollback();
                    throw; // Rethrow the exception
                }
            }
        }
    }
    catch (MySqlException ex)
    {
        HandleDatabaseException(ex, "Error deleting item and related records from the database.");
    }
}



        // Maps data from a MySqlDataReader to an InventoryItem
      private InventoryItem MapInventoryItem(MySqlDataReader reader)
{
    var item = new InventoryItem
    {
        product_id = reader["product_id"] is DBNull ? (int?)null : Convert.ToInt32(reader["product_id"]),
        product_name = reader["product_name"] is DBNull ? null : Convert.ToString(reader["product_name"]),
        description = reader["description"] is DBNull ? null : Convert.ToString(reader["description"]),
        price = reader["price"] is DBNull ? (double?)null : Convert.ToDouble(reader["price"]),
        category = reader["category"] is DBNull ? null : Convert.ToString(reader["category"]),
        stock_quantity = reader["stock_quantity"] is DBNull ? (int?)null : Convert.ToInt32(reader["stock_quantity"]),
    };

    // Check if there are associated photos
    if (reader["photo_id"] != DBNull.Value)
    {
        item.photo_id = Convert.ToInt32(reader["photo_id"]);
        item.photo_data = Convert.ToString(reader["photo_data"]);
    }

    return item;
}


        // Sets parameters for adding or updating an InventoryItem in a MySqlCommand
        private void AddInventoryItemParameters(MySqlCommand command, InventoryItem item)
        {
            command.Parameters.AddWithValue("@product_name", item.product_name);
            command.Parameters.AddWithValue("@description", item.description);
            command.Parameters.AddWithValue("@price", item.price);
            command.Parameters.AddWithValue("@category", item.category);
            command.Parameters.AddWithValue("@stock_quantity", item.stock_quantity);
        }

        // Handles exceptions related to database operations
        private void HandleDatabaseException(MySqlException ex, string errorMessage)
        {
            Console.WriteLine($"{errorMessage}\nError Code: {ex.ErrorCode}\nMessage: {ex.Message}");
            // You might want to log the exception or handle it in a more appropriate way
        }
    }
}
