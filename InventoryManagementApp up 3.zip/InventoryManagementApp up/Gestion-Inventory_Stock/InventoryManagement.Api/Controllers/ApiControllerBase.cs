using System.Net;
using System.Threading.Tasks;

namespace InventoryManagement.Api.Controllers
{
    public abstract class ApiControllerBase
    {
        public abstract Task HandleRequestAsync(HttpListenerContext context);
    }
}
