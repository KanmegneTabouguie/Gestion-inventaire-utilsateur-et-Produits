// ManagementUserController.cs

using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using InventoryManagement.Api.Models;
using InventoryManagement.Api.Repositories;

namespace InventoryManagement.Api.Controllers
{
    public class ManagementUserController : ApiControllerBase
    {
        private readonly ManagementUserRepository _userRepository = new ManagementUserRepository();

        

        public override async Task HandleRequestAsync(HttpListenerContext context)
        {
            try
            {
                var request = context.Request;
                var response = context.Response;

                // Extract version from the request URL
                var version = GetApiVersion(request.Url);

                switch (request.HttpMethod)
                {
                    case "GET":
                        await HandleGetRequestAsync(request, response, version);
                        break;
                    case "POST":
                        await HandlePostRequestAsync(request, response, version);
                        break;
                    case "PUT":
                        await HandlePutRequestAsync(request, response, version);
                        break;
                    case "DELETE":
                        await HandleDeleteRequestAsync(request, response, version);
                        break;
                    default:
                        response.StatusCode = (int)HttpStatusCode.MethodNotAllowed;
                        break;
                }
            }
            catch (Exception ex)
            {
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                await WriteTextToResponseAsync(context.Response, $"Internal server error: {ex.Message}");
            }
            finally
            {
                context.Response.Close();
            }
        }

        private async Task HandleGetRequestAsync(HttpListenerRequest request, HttpListenerResponse response, string version)
        {
            if (request.RawUrl == $"/api/{version}/users")
            {
                var users = await _userRepository.GetAllUsersAsync();
                await WriteJsonToResponseAsync(response, users);
            }
            else if (request.RawUrl != null && request.RawUrl.StartsWith($"/api/{version}/users/"))
            {
                var idString = request.RawUrl.Substring($"/api/{version}/users/".Length);
                if (int.TryParse(idString, out int id))
                {
                    var user = await _userRepository.GetUserByIdAsync(id);
                    if (user != null)
                        await WriteJsonToResponseAsync(response, user);
                    else
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        private async Task HandlePostRequestAsync(HttpListenerRequest request, HttpListenerResponse response, string version)
        {
            if (request.RawUrl == $"/api/{version}/users")
            {
                var user = await ReadJsonFromRequestAsync<ManagementUser>(request);
                if (user != null)
                {
                    await _userRepository.AddUserAsync(user);
                    response.StatusCode = (int)HttpStatusCode.OK;
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        private async Task HandlePutRequestAsync(HttpListenerRequest request, HttpListenerResponse response, string version)
        {
            if (request.RawUrl?.StartsWith($"/api/{version}/users/") == true)
            {
                var idString = request.RawUrl.Substring($"/api/{version}/users/".Length);
                if (int.TryParse(idString, out int id))
                {
                    var existingUser = await _userRepository.GetUserByIdAsync(id);
                    if (existingUser != null)
                    {
                        var updatedUser = await ReadJsonFromRequestAsync<ManagementUser>(request);
                        if (updatedUser != null)
                        {
                            updatedUser.user_id = id;
                            await _userRepository.UpdateUserAsync(updatedUser);
                            response.StatusCode = (int)HttpStatusCode.OK;
                        }
                        else
                        {
                            response.StatusCode = (int)HttpStatusCode.BadRequest;
                        }
                    }
                    else
                    {
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                    }
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        private async Task HandleDeleteRequestAsync(HttpListenerRequest request, HttpListenerResponse response, string version)
        {
            if (request.RawUrl?.StartsWith($"/api/{version}/users/") == true)
            {
                var idString = request.RawUrl.Substring($"/api/{version}/users/".Length);
                if (int.TryParse(idString, out int id))
                {
                    var existingUser = await _userRepository.GetUserByIdAsync(id);
                    if (existingUser != null)
                    {
                        await _userRepository.DeleteUserAsync(id);
                        response.StatusCode = (int)HttpStatusCode.OK;
                    }
                    else
                    {
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                    }
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        private async Task<T?> ReadJsonFromRequestAsync<T>(HttpListenerRequest request) where T : class
        {
            try
            {
                using (var body = request.InputStream)
                using (var reader = new StreamReader(body, request.ContentEncoding))
                {
                    var json = await reader.ReadToEndAsync();
                    return JsonConvert.DeserializeObject<T>(json);
                }
            }
            catch
            {
                return null;
            }
        }

        private async Task WriteJsonToResponseAsync(HttpListenerResponse response, object obj)
        {
            response.ContentType = "application/json";
            var json = JsonConvert.SerializeObject(obj);
            await WriteTextToResponseAsync(response, json);
        }

        private async Task WriteTextToResponseAsync(HttpListenerResponse response, string text)
        {
            using (var output = response.OutputStream)
            {
                var bytes = Encoding.UTF8.GetBytes(text);
                await output.WriteAsync(bytes, 0, bytes.Length);
            }
        }

        private string GetApiVersion(Uri? requestUrl)
        {
            if (requestUrl != null)
            {
                var segments = requestUrl.Segments;
                if (segments.Length > 2 && segments[1].Equals("api", StringComparison.OrdinalIgnoreCase))
                {
                    return segments[2].TrimEnd('/');
                }
            }

            return "v1";
        }
    }
}
