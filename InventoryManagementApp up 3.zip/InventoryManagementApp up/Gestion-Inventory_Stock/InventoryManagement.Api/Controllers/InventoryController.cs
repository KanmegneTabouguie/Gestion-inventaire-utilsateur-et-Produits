// InventoryController.cs

using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using InventoryManagement.Api.Models;
using InventoryManagement.Api.Repositories;

namespace InventoryManagement.Api.Controllers
{
    public class InventoryController : ApiControllerBase
    {
        private readonly InventoryRepository _repository = new InventoryRepository();

        // Add this constructor
    

        public override async Task HandleRequestAsync(HttpListenerContext context)
        {
            try
            {
                var request = context.Request;
                var response = context.Response;

                // Extract version from the request URL
                var version = GetApiVersion(request.Url);

                switch (request.HttpMethod)
                {
                    case "GET":
                        await HandleGetRequestAsync(request, response, version);
                        break;
                    case "POST":
                        await HandlePostRequestAsync(request, response, version);
                        break;
                    case "PUT":
                        await HandlePutRequestAsync(request, response, version);
                        break;
                    case "DELETE":
                        await HandleDeleteRequestAsync(request, response, version);
                        break;
                    default:
                        response.StatusCode = (int)HttpStatusCode.MethodNotAllowed;
                        break;
                }
            }
            catch (Exception ex)
            {
                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                await WriteTextToResponseAsync(context.Response, $"Internal server error: {ex.Message}");
            }
            finally
            {
                context.Response.Close();
            }
        }

        private async Task HandleGetRequestAsync(HttpListenerRequest request, HttpListenerResponse response, string version)
        {
            if (request.RawUrl == $"/api/{version}/inventory")
            {
                var items = new List<InventoryItem>();
                items = await _repository.GetItemsAsync() ;
                //var items = await _repository.GetItemsAsync() ?? new List<InventoryItem>();
                await WriteJsonToResponseAsync(response, items);
            }
            else if (request.RawUrl != null && request.RawUrl.StartsWith($"/api/{version}/inventory/"))
            {
                var idString = request.RawUrl.Substring($"/api/{version}/inventory/".Length);
                if (int.TryParse(idString, out int id))
                {
                    var item = await _repository.GetItemByIdAsync(id);
                    if (item != null)
                        await WriteJsonToResponseAsync(response, item);
                    else
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        private async Task HandlePostRequestAsync(HttpListenerRequest request, HttpListenerResponse response, string version)
        {
            if (request.RawUrl == $"/api/{version}/inventory")
            {
                var item = await ReadJsonFromRequestAsync<InventoryItem>(request);
                if (item != null)
                {
                    await _repository.AddItemAsync(item);
                    response.StatusCode = (int)HttpStatusCode.OK;
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        private async Task HandlePutRequestAsync(HttpListenerRequest request, HttpListenerResponse response, string version)
        {
            if (request.RawUrl?.StartsWith($"/api/{version}/inventory/") == true)
            {
                var idString = request.RawUrl.Substring($"/api/{version}/inventory/".Length);
                if (int.TryParse(idString, out int id))
                {
                    var existingItem = await _repository.GetItemByIdAsync(id);
                    if (existingItem != null)
                    {
                        var updatedItem = await ReadJsonFromRequestAsync<InventoryItem>(request);
                        if (updatedItem != null)
                        {
                            updatedItem.product_id = id;
                            await _repository.UpdateItemAsync(updatedItem);
                            response.StatusCode = (int)HttpStatusCode.OK;
                        }
                        else
                        {
                            response.StatusCode = (int)HttpStatusCode.BadRequest;
                        }
                    }
                    else
                    {
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                    }
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        private async Task HandleDeleteRequestAsync(HttpListenerRequest request, HttpListenerResponse response, string version)
        {
            if (request.RawUrl?.StartsWith($"/api/{version}/inventory/") == true)
            {
                var idString = request.RawUrl.Substring($"/api/{version}/inventory/".Length);
                if (int.TryParse(idString, out int id))
                {
                    var existingItem = await _repository.GetItemByIdAsync(id);
                    if (existingItem != null)
                    {
                        await _repository.DeleteItemAsync(id);
                        response.StatusCode = (int)HttpStatusCode.OK;
                    }
                    else
                    {
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                    }
                }
                else
                {
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                }
            }
            else
            {
                response.StatusCode = (int)HttpStatusCode.NotFound;
            }
        }

        private async Task<T?> ReadJsonFromRequestAsync<T>(HttpListenerRequest request) where T : class
        {
            try
            {
                using (var body = request.InputStream)
                using (var reader = new StreamReader(body, request.ContentEncoding))
                {
                    var json = await reader.ReadToEndAsync();
                    return JsonConvert.DeserializeObject<T>(json);
                }
            }
            catch
            {
                return null;
            }
        }
//conçu pour envoyer des reponses json
        private async Task WriteJsonToResponseAsync(HttpListenerResponse response, object obj)
        {
            response.ContentType = "application/json";
            var json = JsonConvert.SerializeObject(obj);
            await WriteTextToResponseAsync(response, json);
        }
//pour envoyer des reponses textuelles
        private async Task WriteTextToResponseAsync(HttpListenerResponse response, string text)
        {
            using (var output = response.OutputStream)
            {
                var bytes = Encoding.UTF8.GetBytes(text);
                await output.WriteAsync(bytes, 0, bytes.Length);
            }
        }

        private string GetApiVersion(Uri? requestUrl)
{
    if (requestUrl != null)
    {
        var segments = requestUrl.Segments;
        if (segments.Length > 2 && segments[1].Equals("api", StringComparison.OrdinalIgnoreCase))
        {
            return segments[2].TrimEnd('/');
        }
    }

    return "v1";
}

    }
}
