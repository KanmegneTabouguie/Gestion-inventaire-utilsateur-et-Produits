# Gestion-Inventory_Stock

mettre en place un API qui permettra de gérer un inventaire de produits, d'effectuer des opérations CRUD  sur les articles et les utilisateurs