﻿using System;
using System.Net;
using System.Threading.Tasks;
using InventoryManagement.Api.Controllers;
using InventoryManagement.Api.Repositories;

namespace InventoryManagement.Api
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Display a message indicating that the application is testing the database connection
            Console.WriteLine("Testing Database Connection...");

            // Create instances of the InventoryRepository and ManagementUserRepository
            InventoryRepository inventoryRepository = new InventoryRepository();
            ManagementUserRepository userRepo = new ManagementUserRepository();

            // Check if the database connection is successful
            if (await inventoryRepository.TestDatabaseConnectionAsync() && await userRepo.TestDatabaseConnectionAsync())
            {
                // Display a success message if the database connection is successful
                Console.WriteLine("Database connection test successful!");

                // Start the API listeners
                Task apiListenerTask = StartApiListener("http://localhost:8483/", new InventoryController());
                Task userApiListenerTask = StartApiListener("http://localhost:8281/", new ManagementUserController());

                // Create an instance of the InventoryCLI to handle interaction via CLI
                InventoryCLI cli = new InventoryCLI();

                // Start the CLI for interaction
                Task cliTask = cli.StartAsync();

                // Wait for either the API listeners or the CLI to complete
                await Task.WhenAny(apiListenerTask, userApiListenerTask, cliTask);

                // Display a message to prompt the user to press any key to exit
                Console.WriteLine("Press any key to exit.");
                // Wait for a key press before exiting the application
                Console.ReadKey();
            }
            else
            {
                // Display an error message if the database connection test fails
                Console.WriteLine("Database connection test failed. Please check your connection string and database server.");
            }
        }

        static async Task StartApiListener(string apiPrefix, ApiControllerBase controller)
        {
            var apiListener = new HttpListener();
            apiListener.Prefixes.Add(apiPrefix);

            Console.WriteLine($"API listening on {apiPrefix}");

            apiListener.Start();

            try
            {
                while (true)
                {
                    var context = await apiListener.GetContextAsync();

                    // Debug print: Print the requested URL
                    Console.WriteLine($"Received request for: {context.Request.Url}");

                    await controller.HandleRequestAsync(context);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                apiListener.Stop();
            }
        }
    }
}

