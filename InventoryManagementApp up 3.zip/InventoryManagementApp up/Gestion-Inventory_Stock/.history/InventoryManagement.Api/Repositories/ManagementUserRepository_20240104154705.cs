using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using InventoryManagement.Api.Models;

namespace InventoryManagement.Api.Repositories
{
    public class ManagementUserRepository
    {
        // Connection string for the MySQL database
        private string connectionString = "Server=127.0.0.1;Database=e-commerce;User Id=root;Password=yvan2021;";

        // Asynchronously tests the connection to the database
        public async Task<bool> TestDatabaseConnectionAsync()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    // Open the database connection
                    await connection.OpenAsync();
                    Console.WriteLine("Connection to the database is successful.");
                    return true;
                }
            }
            catch (MySqlException ex)
            {
                // Handle MySQL-specific exceptions related to database connection
                Console.WriteLine($"Database connection error: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                // Handle general exceptions related to database connection
                Console.WriteLine($"Error connecting to the database: {ex.Message}");
                return false;
            }
        }

         // Asynchronously retrieves a user by their ID from the database
    public async Task<ManagementUser?> GetUserByIdAsync(int id)
    {
        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (MySqlCommand command = new MySqlCommand("SELECT * FROM user WHERE user_id = @user_id", connection))
                {
                    command.Parameters.AddWithValue("@user_id", id);

                    using (MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return MapManagementUser(reader);
                        }
                    }
                }
            }
        }
        catch (MySqlException ex)
        {
            HandleDatabaseException(ex, "Error fetching user by ID from the database.");
        }

        return null;
    }

    // Asynchronously retrieves all users from the database
public async Task<List<ManagementUser>> GetAllUsersAsync()
{
    List<ManagementUser> users = new List<ManagementUser>();

    try
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            await connection.OpenAsync();

            // Execute a SELECT query to fetch all users from the 'user' table
            using (MySqlCommand command = new MySqlCommand("SELECT * FROM user", connection))
            using (MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                {
                    ManagementUser user = MapManagementUser(reader);
                    users.Add(user);
                }
            }
        }
    }
    catch (MySqlException ex)
    {
        HandleDatabaseException(ex, "Error fetching all users from the database.");
    }

    return users;
}


public async Task AddUserAsync(ManagementUser user)
{
    try
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            await connection.OpenAsync();

            // Execute an INSERT query to add a new user to the 'users' table
            using (MySqlCommand command = new MySqlCommand("INSERT INTO user (username, email, password, first_name, last_name, phone_number, registration_date) VALUES (@username, @email, @password, @first_name, @last_name, @phone_number, @registration_date)", connection))
            {
                // Set parameters for the new user
                AddManagementUserParameters(command, user);

                // Execute the query
                await command.ExecuteNonQueryAsync();
            }
        }
    }
    catch (MySqlException ex)
    {
        // Handle exceptions related to adding a user to the database
        HandleDatabaseException(ex, "Error adding user to the database.");
    }
}


        // Asynchronously updates an existing user in the database
    public async Task UpdateUserAsync(ManagementUser user)
    {
        try
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (MySqlCommand command = new MySqlCommand("UPDATE user SET username = @username, email = @email, password = @password, first_name = @first_name, last_name = @last_name, phone_number = @phone_number, registration_date = @registration_date WHERE user_id = @user_id", connection))
                {
                    command.Parameters.AddWithValue("@user_id", user.user_id);
                    AddManagementUserParameters(command, user);
                    await command.ExecuteNonQueryAsync();
                }
            }
        }
        catch (MySqlException ex)
        {
            HandleDatabaseException(ex, "Error updating user in the database.");
        }
    }

    

         // Asynchronously deletes an existing user from the database
public async Task DeleteUserAsync(int id)
{
    try
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            await connection.OpenAsync();

            // Delete associated carts
            using (MySqlCommand deleteCartsCommand = new MySqlCommand("DELETE FROM cart WHERE user_id = @user_id", connection))
            {
                deleteCartsCommand.Parameters.AddWithValue("@user_id", id);
                await deleteCartsCommand.ExecuteNonQueryAsync();
            }

           // Delete associated contactus
            using (MySqlCommand deleteContactusCommand = new MySqlCommand("DELETE FROM contactus WHERE user_id = @user_id", connection))
            {
                deleteContactusCommand.Parameters.AddWithValue("@user_id", id);
                await deleteContactusCommand.ExecuteNonQueryAsync();
            }

        //Delete associated payement
            using (MySqlCommand deletePayementCommand = new MySqlCommand("DELETE FROM payement WHERE user_id = @user_id", connection))
            {
                deletePayementCommand.Parameters.AddWithValue("@user_id", id);
                await deletePayementCommand.ExecuteNonQueryAsync();
            }
            // Delete associated addresses
            using (MySqlCommand deleteAddressesCommand = new MySqlCommand("DELETE FROM address WHERE user_id = @user_id", connection))
            {
                deleteAddressesCommand.Parameters.AddWithValue("@user_id", id);
                await deleteAddressesCommand.ExecuteNonQueryAsync();
            }

          // Delete associated notification
            using (MySqlCommand deleteNotificationCommand = new MySqlCommand("DELETE FROM notification WHERE user_id = @user_id", connection))
            {
                deleteNotificationCommand.Parameters.AddWithValue("@user_id", id);
                await deleteNotificationCommand.ExecuteNonQueryAsync();
            }
            // Delete associated commands
            using (MySqlCommand deleteCommandsCommand = new MySqlCommand("DELETE FROM command WHERE user_id = @user_id", connection))
            {
                deleteCommandsCommand.Parameters.AddWithValue("@user_id", id);
                await deleteCommandsCommand.ExecuteNonQueryAsync();
            }

            // Delete the user
            using (MySqlCommand deleteUserCommand = new MySqlCommand("DELETE FROM user WHERE user_id = @user_id", connection))
            {
                deleteUserCommand.Parameters.AddWithValue("@user_id", id);
                await deleteUserCommand.ExecuteNonQueryAsync();
            }
        }
    }
    catch (MySqlException ex)
    {
        HandleDatabaseException(ex, "Error deleting user and associated carts/addresses/commands from the database.");
    }
}


         // Map data from a MySqlDataReader to a ManagementUser
    private ManagementUser MapManagementUser(MySqlDataReader reader)
    {
        return new ManagementUser
        {
            user_id = Convert.ToInt32(reader["user_id"]),
            username = Convert.ToString(reader["username"]),
            email = Convert.ToString(reader["email"]),
            password = Convert.ToString(reader["password"]),
            first_name = Convert.ToString(reader["first_name"]),
            last_name = Convert.ToString(reader["last_name"]),
            phone_number =  Convert.ToString(reader["phone_number"]),
            registration_date = Convert.ToDateTime(reader["registration_date"]).ToString("yyyy-MM-dd HH:mm:ss")
        };
    }

        // Sets parameters for adding or updating an InventoryItem in a MySqlCommand
         private void AddManagementUserParameters(MySqlCommand command, ManagementUser user)
    {
        command.Parameters.AddWithValue("@username", user.username);
        command.Parameters.AddWithValue("@email", user.email);
        command.Parameters.AddWithValue("@password", user.password);
        command.Parameters.AddWithValue("@first_name", user.first_name);
        command.Parameters.AddWithValue("@last_name", user.last_name);
        command.Parameters.AddWithValue("@phone_number", user.phone_number);
        command.Parameters.AddWithValue("@registration_date", user.registration_date);
    }

        // Handles exceptions related to database operations
        private void HandleDatabaseException(MySqlException ex, string errorMessage)
        {
            Console.WriteLine($"{errorMessage}\nError Code: {ex.ErrorCode}\nMessage: {ex.Message}");
            // You might want to log the exception or handle it in a more appropriate way
        }
    }
}
